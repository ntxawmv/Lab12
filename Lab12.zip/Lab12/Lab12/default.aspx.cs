﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab12
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearch.Text))
            {
                //what we could do
                //Response.Write("Please enter valid search keyword!");
                //more elegant way
                lblError.Text = ("Please enter valid search keyword!");
                //return would mean to stop the following code.
                //if we didn't put this it would still run the following code below.
                return;
            }

            lblError.Text = string.Empty;
            
            // get data
            var books = Books.GetBooks();

            //sourt data (linq)
            var sortedBooks = from bookItem in books
                              where bookItem.Title.Contains(txtSearch.Text)
                              //if you search by price, adding deceding at the end of the orderby line
                              //will allow you to order the lines by decending prices.
                              orderby bookItem.Price //decending 
                              select bookItem;

            //this binds the value to the datasource. 
            GridView1.DataSource = sortedBooks;
            //must always call this method after setting datasource.
            GridView1.DataBind(); 
        }
    }
}